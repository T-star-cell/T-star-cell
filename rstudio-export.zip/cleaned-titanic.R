titanic_data <- read.csv("Titanic-Dataset.csv")
View(titanic_data)
summary(titanic_data)
str(titanic_data)
# Check for missing values
colSums(is.na(titanic_data))

# Example: Filling missing Age values with median
titanic_data <- titanic_data %>%
  mutate(Age = ifelse(is.na(Age), median(Age, na.rm = TRUE), Age))

# Verify that missing values have been filled
colSums(is.na(titanic_data))
# Example: Convert 'Survived' to factor
titanic_data <- titanic_data %>%
  mutate(Survived = as.factor(Survived))
write.csv(titanic_data, "Cleaned_Titanic_Data.csv", row.names = FALSE)
