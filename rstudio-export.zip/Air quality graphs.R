data(airquality)
head(airquality)
str(airquality)
ggplot(airquality, aes(x = 1:nrow(airquality), y = Ozone)) +
  geom_line(color = "blue") +
  xlab("Day") +
  ylab("Ozone") +
  ggtitle("Time Series Plot of Ozone Levels")

ggplot(airquality, aes(x = as.factor(Month), y = Ozone)) +
  geom_boxplot() +
  xlab("Month") +
  ylab("Ozone") +
  ggtitle("Boxplot of Ozone by Month")

ggplot(airquality, aes(x = Temp)) +
  geom_histogram(binwidth = 1, fill = "red", color = "black") +
  xlab("Temperature") +
  ylab("Count") +
  ggtitle("Histogram of Temperature")

ggplot(airquality, aes(x = Wind, y = Ozone)) +
  geom_point(color = "green") +
  xlab("Wind") +
  ylab("Ozone") +
  ggtitle("Scatter Plot of Ozone vs. Wind")

ggplot(airquality, aes(x = Wind, y = Ozone)) +
  geom_point() +
  facet_wrap(~ Month) +
  xlab("Wind") +
  ylab("Ozone") +
  ggtitle("Ozone vs. Wind by Month")
