data(iris)
head(iris)
str(iris)
colSums(is.na(iris))
iris$Sepal.Length[1] <- NA  # Introduce a missing value
iris$Sepal.Length <- ifelse(is.na(iris$Sepal.Length), mean(iris$Sepal.Length, na.rm = TRUE), iris$Sepal.Length)
iris$Species <- as.factor(iris$Species)
str(iris)
names(iris) <- tolower(names(iris))
names(iris) <- gsub("\\.", "_", names(iris))
iris <- iris[!duplicated(iris), ]
iris <- iris %>%
  mutate(petal_length_width_ratio = petal_length / petal_width)
summary(iris)
str(iris)
