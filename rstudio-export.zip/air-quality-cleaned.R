data(airquality)
head(airquality)
str(airquality)
colSums(is.na(airquality))
airquality$Ozone <- ifelse(is.na(airquality$Ozone), median(airquality$Ozone, na.rm = TRUE), airquality$Ozone)
airquality$Solar.R <- ifelse(is.na(airquality$Solar.R), median(airquality$Solar.R, na.rm = TRUE), airquality$Solar.R)

airquality$Month <- as.factor(airquality$Month)
airquality$Day <- as.factor(airquality$Day)
airquality$Month <- as.factor(airquality$Month)
airquality$Day <- as.factor(airquality$Day)
airquality <- airquality[!duplicated(airquality), ]
summary(airquality)
str(airquality)
